#ifndef ENTITY_H     /*ifndef checks if ENTITY_H is not defined*/
#define ENTITY_H     /*If ENTITY_H is not defined, define it*/

typedef enum {
    PLAYER, BOX, GOAL    /*Define an enum type named entity_type_t with three values: PLAYER, BOX, GOAL*/
} entity_type_t;

typedef struct {
    int x;                /*Define an integer member variable x*/
    int y;                /*Define an integer member variable y*/
    entity_type_t type;   /*Define a member variable type of enum type entity_type_t*/
} entity_t;               /*Define a struct type named entity_t with three member variables: x, y, and type*/

#endif /* ENTITY_H */     /*End of ifndef/define block, ENTITY_H is now defined.*/