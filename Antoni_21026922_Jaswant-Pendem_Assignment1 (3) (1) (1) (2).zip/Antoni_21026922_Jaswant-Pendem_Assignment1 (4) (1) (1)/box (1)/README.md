Assignment One - Unix & C Programming (COMP1000) - Semester 1, 2023

Provided Code 
- color.c
- color.h
- colortest.c
- interface.c
- random.c
- random.h
- randomtest.c
- terminal.c
- terminal.h

Own Code
- map.c
- map.h
- game.c
- game.h
- main.c
- colortest.h
- entity.h
- Dependencies: Makefile


Additionally:
-val.out created
- 0 warnings, 0 errors during the compilation of the code.
- Valgrind (0 memory leaks, 0 errors) during gameplay 
- Zero crashes 

-.vscode files were randomly generated, and when removed are instantaneously back.