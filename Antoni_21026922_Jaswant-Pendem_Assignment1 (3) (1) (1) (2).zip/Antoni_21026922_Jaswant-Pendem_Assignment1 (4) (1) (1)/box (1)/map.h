#ifndef MAP_H
#define MAP_H

#include "entity.h"

#define ENTITY_COUNT 3 /* Define a constant macro for the number of entities in the map */

typedef struct {
    int y;                     /* Dimensions of map (y-axis) */
    int x;                     /* Dimensions of map (x-axis) */
    int end;                   /* End flag */
    int** map_array;           /* 2D map array */
    entity_t e[ENTITY_COUNT]; /* Entities (player, box, goal) */
} map_t; 

void map_display(map_t* map); /* Declare a function 'map_display' that takes a pointer to a 'map_t' structure as an argument */
int map_move_entity(int ry, int rx, map_t* map, int eid); /* Declare a function 'map_move_entity' that takes three integers and a pointer to a 'map_t' structure as arguments and returns an integer */
void map_initialize(map_t* map, int arg[6]); /* Declare a function 'map_initialize' that takes a pointer to a 'map_t' structure and an array of integers as arguments */

#endif /* MAP_H */

