#include "game.h" /*header file*/
#include <unistd.h> /*Include the header for sleep()*/ /*Warning: For increase time for invalid key*/
#include "stdio.h" /*stdio.h header file*/

void game_run(map_t* map)
{
    char c;
    while(!map->end) { /* while end member of map structure is not true*/
        map_display(map); /* Display the map*/
        c = getchar(); /*Read character from input*/
        switch(c) {   /* Start a switch statement based on the value of the character read*/
        case 'w':   /*If caharcter is w */
            map_move_entity(-1, 0, map, 0); /*Move the entity on the map up by calling the function map _move_entity() with arguments (-1,0) to represent the change in x and y coords, and passing iin the map object and 0 as the last argument*/
            break; /*Exit switch statement*/
        case 's': /*If the character is s*/
            map_move_entity(1, 0, map, 0); /*Move the entity on the map down by calling the function map_move_entity() with arguments (1, 0) to represent the change in x and y coords, and passing in the map object and 0 as the last argument*/
            break; /*Exit the switch statement*/
        case 'a': /*If charcter is a*/
            map_move_entity(0, -1, map, 0); /* Move the entity on the map left by calling the function map_move_entity() with arguments (0, -1) to represent the change in x and y coords, and passing in the map object and 0 as the last argument*/
            break; /*Exit switch statement*/
        case 'd': /* If the character is d*/
            map_move_entity(0, 1, map, 0); /*Move the entity on the map right by calling the function map_move_entity() with arguments (0, 1) to represent the change in x and y coords, and passing in the map object and 0 as the last argument*/
            break; /*Exit the switch statement*/
        default: /*If the character does not match any of the cases above*/
            printf("Invalid key! Please use w, s, a, or d to move.\n"); /*Error message for invalid keys*/
            sleep(2); /*2 second time showing Invalid Key.. whenever pressed*/
            break; /*Exit the switch statement*/
        }
    }
    map_display(map); /*call the map_display function with the map argument*/
    puts("You win!!"); /*Print "You win!!" to the standard output*/
}

