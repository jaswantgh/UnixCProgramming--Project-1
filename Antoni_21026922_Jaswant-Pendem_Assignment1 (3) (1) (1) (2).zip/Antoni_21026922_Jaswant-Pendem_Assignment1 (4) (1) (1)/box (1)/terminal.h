#ifndef TERMINAL_H
#define TERMINAL_H

void disable_buffer(void);
void enable_buffer(void);

#endif /* TERMINAL_H */