#include "map.h" /*Header File*/
#include "color.h" /*Header File*/
#include "random.h" /*Header File*/

#include <stdio.h> /*Standard input/output library*/
#include <stdlib.h> /*Standard Library*/

#define min(a, b) (a < b ? a : b)
/*Define macro function, returns min value between a and b*/
#define max(a, b) (a > b ? a : b)
/*Define macro function, returns max value between a and b*/

void map_put_character(map_t* map, int y, int x) 
{ /* Character on map at coordinates (x,y)*/
    int i;
    char c = ' ';
    for(i = ENTITY_COUNT - 1; i >= 0; --i) {
        if(map->e[i].x == x && map->e[i].y == y) {
            switch(map->e[i].type) {
            case PLAYER:
                c = 'P';
                break;
            case BOX:
                c = 'B';
                break;
            case GOAL:
                c = 'G';
                if(map->end) {
                    setBackground("green");
                } else {
                    setBackground("red");
                    /*Background resets*/
                }
                break;
            }
        }
    }
    putchar(c);
    setBackground("reset");
}


/* Map on screen is displayed */
void map_display(map_t* map) 
{   
    /* Iterating through each cell of the map, calling map_put_character() function to put the appropriate character at each cell */
    int i, j;
    system("clear");
    for(j = 0; j < map->x + 2; ++j) {
        /* Use of asterisk (*) characters to form a border */
        putchar('*');
    }
    putchar('\n');
    for(i = 0; i < map->y; ++i) {
        putchar('*');
        for(j = 0; j < map->x; ++j) {
            map_put_character(map, i, j);
        }
        putchar('*');
        putchar('\n');
    }
    for(j = 0; j < map->x + 2; ++j) {
        putchar('*');
    }
    putchar('\n');
    /* Game Instructions defined and printed */
    puts("Move the box to the goal to win the game!");
    puts("Press w to move up");
    puts("Press s to move down");
    puts("Press a to move left");
    puts("Press d to move right");
}



int map_move_entity(int ry, int rx, map_t* map, int eid)
{
    int i;
    entity_t* e = &map->e[eid];
    /* Original position for comparison*/
    int ox = e->x;
    int oy = e->y;

    e->y += ry;
    e->x += rx;

    /* Boundary adjustment */
    e->x = max(0, e->x);
    e->x = min(map->x - 1, e->x);
    e->y = max(0, e->y);
    e->y = min(map->y - 1, e->y);

    for(i = 0; i < ENTITY_COUNT; ++i) {
        if(i != eid) {
            entity_t* other = &map->e[i];
            /*PULL Conditional Compilation*/
#ifdef PULL
            if(other->x == ox - rx && other->y == oy - ry) {
                if(other->type == BOX) {
                    if(e->x != ox || e->y != oy) {
                        map_move_entity(ry, rx, map, i);
                    }
                }
            }
#endif
            if(other->x == e->x && other->y == e->y) {
                if(other->type == BOX) {
                    /* Undo if cannot move the box */
                    if(!map_move_entity(ry, rx, map, i)) {
                        map_move_entity(-ry, -rx, map, eid);
                    }
                }
            }
            /* Victory condition */
            if(other->x == e->x && other->y == e->y 
            && other->type == GOAL && e->type == BOX) {
                map->end = 1;
            }
        }
    }

    return e->x != ox || e->y != oy;
}



void map_initialize(map_t* map, int arg[6])
{
    /* Initialisation of map and entities based on arguments */
    /* Arguments passed in an integer array of size 6 */
    int i;
    map->end = 0;

    /* Fail if arg < 0 */
    for(i = 0; i < 6; ++i) {
        if(arg[i] < 0) {
            map->end = 1;
        }
    }

    /* First two arguments represent dimensions of map ( y and x) */
    /* Initialize bounds */
    map->y = arg[0];
    map->x = arg[1];

    /* Dynamically allocate memory for the 2D map array */
    map->map_array = (int**)malloc(map->y * sizeof(int*));
    for (i = 0; i < map->y; ++i){
        map->map_array[i] = (int*)malloc(map->x * sizeof(int));
    }           

    /* Next four arguments represent the initial positions of the player, box, and goal entities */
    /* Initialize main entities */
    map->e[0].type = PLAYER;
    map->e[0].y = arg[2];
    map->e[0].x = arg[3];

    map->e[2].type = GOAL;
    map->e[2].y = arg[4];
    map->e[2].x = arg[5];

    /* Check for overlaps between entities and set map->end flag to 1 if any overlaps are found */
    /* Fail if player overlaps goal */
    if(map->e[0].x == map->e[2].x && map->e[0].y == map->e[2].y) {
        map->end = 1;
    }

    /* The function also sets the position of the box entity randomly, making sure it does not overlap with the player or goal entities */
    /* Initialize box */
    map->e[1].type = BOX;
    do {
        map->e[1].y = randomUCP(1, map->y - 2);
        map->e[1].x = randomUCP(1, map->x - 2);
    } while((map->e[1].x == map->e[0].x && map->e[1].y == map->e[0].y)
         || (map->e[1].x == map->e[2].x && map->e[1].y == map->e[2].y));
}


