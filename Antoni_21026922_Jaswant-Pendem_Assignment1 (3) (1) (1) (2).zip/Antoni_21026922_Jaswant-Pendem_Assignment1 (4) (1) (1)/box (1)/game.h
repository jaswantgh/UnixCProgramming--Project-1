#ifndef GAME_H /* If GAME_H is not defined*/
#define GAME_H /* Defined to prevent multiple inclusion of header file*/

#include "map.h" /*Header File*/

void game_run(map_t* map); /* Declare function called game_run that takes a pointer to map_t as an argument*/

#endif /* GAME_H */  
/*Endif used to end ifndef and conditional block*/