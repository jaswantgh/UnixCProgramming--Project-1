
#ifndef COLORTEST_H
#define COLORTEST_H

/* Function declarations*/
void setBackground(char* color);

#endif /*COLORTEST_H*/
