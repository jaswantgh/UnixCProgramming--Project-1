#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "terminal.h"
/* inorder to disable the Echo and Canonical temporarily*/
#include "map.h"
#include "game.h"
#include "random.h"

int main(int argc, char** argv)
{
    if(argc != 7) { /*If the number of command-line arguments is not equal to 7*/
        printf("Usage: %s <map_row> <map_col> <player_row> <player_col> <goal_row> <goal_col>\n", argv[0]);
    } else {
        int* arg; /*Declare a pointer to an integer to store command-line argument values*/
        int i; /*Declare a loop counter variable*/
        map_t map; /*Declare a map object*/
        arg = malloc(sizeof(int) * 6); /*Allocate memory to store 6 integer values for command-line arguments*/
         
        initRandom(); /*Call a function to initialize random number generator*/
        disable_buffer(); /* Call a function to disable input buffering to allow for immediate input*/

        for(i = 0; i < 6; ++i) { /*Loop through the command-line arguments from argv[1] to argv[6]*/
            arg[i] = atoi(argv[i + 1]); /*Convert the command-line argument from string to integer using atoi() and store it in the dynamically allocated 'arg' array*/
        }

        map_initialize(&map, arg); /*Call a function to initialize the map object with the integer values from 'arg'*/
        free(arg); /* Free the allocated memory for 'arg' as it is no longer needed*/

        if(!map.end) { /*If the 'end' flag in the map object is not set*/
            game_run(&map); /*Call a function to run the game using the map object*/
        } else {
            puts("Invalid argument values!"); /*Print an error message indicating invalid argument values*/
        }
        
        enable_buffer(); /*Call a function to enable input buffering*/
    }
    return 0; /*Return 0 to indicate successful program execution*/
}
